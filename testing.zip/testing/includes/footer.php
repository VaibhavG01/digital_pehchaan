<footer class="bg-gray-800 p-4 text-white text-center">
    <p>&copy; 2024 MyWebsite. All Rights Reserved.</p>
</footer>
</body>
</html>
